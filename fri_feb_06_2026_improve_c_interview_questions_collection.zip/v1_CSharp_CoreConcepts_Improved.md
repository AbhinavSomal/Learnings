### Part 1: Core C# Concepts

**1. Difference between `readonly` vs `const`**
*   **`const`**: The value is a compile-time constant. It must be initialized at declaration and cannot be changed. It is implicitly `static`.
*   **`readonly`**: The value is a runtime constant. It can be initialized either at declaration or within the constructor of the class. It can be instance-level or `static`.

**2. What is a `sealed` keyword used for?**
The `sealed` keyword is used to prevent inheritance.
*   When applied to a **class**, it prevents other classes from inheriting from it.
*   When applied to a **method or property**, it prevents that member from being overridden in a derived class.

**3. Name all the access modifiers for types**
The main access modifiers in C# are:
*   `public`: Accessible from anywhere.
*   `private`: Accessible only within the same class or struct.
*   `protected`: Accessible within the same class and by derived classes.
*   `internal`: Accessible only within the same assembly.
*   `protected internal`: Accessible within the same assembly OR by derived classes in other assemblies.
*   `private protected`: Accessible by derived classes within the same assembly.

**4. Difference between `interface` and `abstract class`**
*   **Interface**: Defines a contract of what a class *can do*. It can only contain signatures of methods, properties, events, or indexers. A class can implement multiple interfaces. It cannot contain instance state (fields).
*   **Abstract Class**: Provides a base with common functionality that derived classes *share*. It can contain both abstract (unimplemented) and concrete (implemented) members, including fields and constructors. A class can inherit from only one abstract class.

**5. When is a static constructor called?**
A static constructor is called automatically **before the first instance of the class is created** or **any static members are referenced**. It is called at most once per application domain.

**6. How to create an extension method?**
You create an extension method by defining a `static` method inside a `static` class. The first parameter of the method specifies the type it extends, preceded by the `this` keyword.
```csharp
public static class StringExtensions
{
    public static int WordCount(this string str)
    {
        return str.Split(new char[] { ' ', '.', '?' }, StringSplitOptions.RemoveEmptyEntries).Length;
    }
}
```

**7. Does C# support multiple class inheritance?**
No, C# does not support multiple inheritance for classes. A class can only inherit from a single base class. However, a class can implement multiple interfaces, which is how C# achieves a form of multiple inheritance for contracts.

**8. Explain boxing and unboxing**
*   **Boxing**: The process of converting a value type (like `int`, `char`, `struct`) into a reference type (`object`). This involves creating a new object on the heap and copying the value type's value into it.
*   **Unboxing**: The process of extracting the value type from the object. This requires an explicit cast and can throw an `InvalidCastException` if the object is not of the expected boxed type.

**9. What is heap and stack?**
*   **Stack**: A region of memory that stores value types, method parameters, and pointers to reference types. It operates in a Last-In, First-Out (LIFO) manner and is managed directly by the CPU for efficient allocation and deallocation.
*   **Heap**: A region of memory used for dynamic allocation of reference types (like classes, strings, arrays). Objects on the heap are not deallocated automatically and are managed by the Garbage Collector (GC).

**10. Difference between `string` and `StringBuilder`**
*   **`string`**: An immutable reference type. Any modification (like concatenation) creates a new string object in memory, which can be inefficient for frequent changes.
*   **`StringBuilder`**: A mutable object designed for efficient string manipulation. It modifies the internal buffer instead of creating new objects, making it much faster for building strings in loops.

**11. How to create a date with a specific timezone?**
You use the `DateTimeOffset` struct, which represents a point in time relative to UTC.
```csharp
// Represents a specific time in a specific time zone (+5:30)
var timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
var dateTime = new DateTime(2025, 12, 25, 10, 30, 0);
var dateTimeWithZone = new DateTimeOffset(dateTime, timeZoneInfo.GetUtcOffset(dateTime));
```

**12. How to change current culture?**
You change the culture for the current thread by setting the `CurrentCulture` and `CurrentUICulture` properties.
```csharp
using System.Globalization;
using System.Threading;

// For formatting numbers, dates, etc.
Thread.CurrentThread.CurrentCulture = new CultureInfo("fr-FR");

// For retrieving culture-specific resources (e.g., language translations)
Thread.CurrentThread.CurrentUICulture = new CultureInfo("fr-FR");
```

**13. What is the difference between `HashSet<T>` and `Dictionary<TKey, TValue>`?**
*   **`HashSet<T>`**: A collection that contains unique elements. It is optimized for high-performance set operations like union, intersection, and checking for an element's existence (`Contains`). It has no ordering.
*   **`Dictionary<TKey, TValue>`**: A collection of key-value pairs. Each key must be unique. It is optimized for fast lookups of a value based on its key.

**14. What is the purpose of the method `ToLookup`?**
`ToLookup` is a LINQ method that groups the elements of a sequence based on a key selector function. It creates an `ILookup<TKey, TElement>`, which is similar to a `Dictionary<TKey, IEnumerable<TElement>>` but optimized for grouped data lookups.

**15. Does LINQ `Cast<T>` method create a new object?**
No, `Cast<T>` does not create new objects for the elements themselves. It attempts to cast each element in the source collection to the specified type `T`. It returns a new `IEnumerable<T>` sequence that enumerates the original items.

**16. Explain deferred execution in LINQ**
Deferred execution means that a LINQ query is not executed at the point it is defined, but rather when the results are actually enumerated (e.g., in a `foreach` loop or by calling a method like `ToList()` or `Count()`).

**17. How does the `ImmutableList<T>` work?**
`ImmutableList<T>` is a collection where any modification operation (like `Add`, `Remove`) does not change the original list. Instead, it returns a **new** `ImmutableList<T>` instance with the change applied, preserving the original list.

---

### Part 2: Concurrency, Collections, and Modern C# Features

**18. What are the benefits of using Frozen Collections?**
Frozen collections (`FrozenDictionary<TKey, TValue>` and `FrozenSet<T>`), introduced in .NET 8, are immutable collections optimized for extremely fast read performance. Once created, they cannot be changed and have zero-copy semantics, making them ideal for scenarios with heavy read traffic.

**19. Name thread-safe collections**
These are collections designed for concurrent access from multiple threads, found in the `System.Collections.Concurrent` namespace:
*   `ConcurrentDictionary<TKey, TValue>`
*   `ConcurrentQueue<T>`
*   `ConcurrentStack<T>`
*   `ConcurrentBag<T>`
*   `BlockingCollection<T>`

**20. How to perform a lock for asynchronous code?**
You should not use the `lock` keyword with `await` inside it, as it can lead to deadlocks. Instead, use `SemaphoreSlim`.
```csharp
private readonly SemaphoreSlim _mutex = new SemaphoreSlim(1, 1);

public async Task DoWorkAsync()
{
    await _mutex.WaitAsync(); // Acquire the lock asynchronously
    try
    {
        // Critical section: code that needs exclusive access
        await Task.Delay(1000);
    }
    finally
    {
        _mutex.Release(); // Release the lock
    }
}
```

**21. Name all the ways for creating a new thread**
*   **`Thread` class (explicit thread creation)**: `Thread t = new Thread(MethodName); t.Start();`
*   **`Task.Run` (Task Parallel Library - TPL)**: `Task.Run(() => { ... });` (This is the modern, preferred approach).
*   **`ThreadPool.QueueUserWorkItem`**: `ThreadPool.QueueUserWorkItem(state => { ... });` (Used by TPL behind the scenes).
*   **`BackgroundWorker`**: A legacy component for managing background operations in UI applications.

**22. How to execute multiple async tasks at once?**
Use `Task.WhenAll` to await the completion of multiple tasks concurrently.
```csharp
Task<int> task1 = Method1Async();
Task<string> task2 = Method2Async();
Task task3 = Method3Async();

// Starts all tasks and waits for all of them to complete
await Task.WhenAll(task1, task2, task3);

// You can now safely access the results
int result1 = task1.Result; // or await task1
string result2 = task2.Result; // or await task2
```

**23. Explain Inheritance vs Composition**
*   **Inheritance** (`is-a` relationship): A class derives from a base class, inheriting its public and protected members. It promotes code reuse but creates a tight coupling between the base and derived classes.
*   **Composition** (`has-a` relationship): A class contains an instance of another class and delegates work to it. It promotes flexibility and loose coupling. Example: A `Car` *has an* `Engine`.

**24. Difference between `class` vs `record` vs `struct`**
*   **`class`**: A reference type. Stored on the heap. Supports inheritance. By default, has reference-based equality (two variables are equal if they point to the same object).
*   **`struct`**: A value type. Stored on the stack (usually). Does not support inheritance (but can implement interfaces). Has value-based equality by default (two structs are equal if their members have the same values).
*   **`record`**: Can be a reference type (`record class`) or a value type (`record struct`). Primarily for immutable data models. The compiler auto-generates methods for value-based equality (`Equals`, `GetHashCode`) and `ToString`.

**25. What are `ref struct`s used for?**
`ref struct`s are value types that are enforced by the compiler to live only on the stack. They can never be boxed, stored on the heap, or be members of a class. They are used for high-performance scenarios where you need stack-allocated data with reference semantics.

**26. Name the two forms of records**
1.  **Positional Records**: A concise syntax where properties are defined in the declaration. The compiler generates a primary constructor and deconstructor.
    ```csharp
    public record Person(string FirstName, string LastName);
    ```
2.  **Nominal Records**: Declared with standard property syntax inside curly braces.
    ```csharp
    public record Person
    {
        public string FirstName { get; init; }
        public string LastName { get; init; }
    }
    ```

**27. What is "with" keyword used for?**
The `with` keyword is used with **records** to create a new record instance by copying an existing instance and modifying some of its properties. This is called **non-destructive mutation**.
```csharp
var person1 = new Person("John", "Doe");
var person2 = person1 with { FirstName = "Jane" }; // person2 is a new record
```

**28. What is the purpose of Primary Constructors?**
Introduced in C# 12 for classes and structs (previously available for records), primary constructors provide a concise way to declare constructor parameters whose values can be used to initialize properties and fields.
```csharp
public class Person(string name, int age)
{
    public string Name { get; } = name;
    public int Age { get; } = age;
}
```

**29. Explain how Nullable Reference Types work**
This is an opt-in feature (enabled with `<Nullable>enable</Nullable>` in the project file) that helps prevent `NullReferenceException`. The compiler performs static analysis to detect potential null issues.
*   **`string name`**: A non-nullable reference type. The compiler will warn you if you try to assign `null` to it or if it's not initialized.
*   **`string? name`**: A nullable reference type. You are explicitly stating that this variable can be `null`, and the compiler will force you to check for `null` before dereferencing it.

**30. Do switch expressions have any return type limitations?**
Yes. All arms of a switch expression must return values of the same type, or types that have an implicit conversion to a single common type. The compiler must be able to determine a single best common type for all branches.

---

### Part 3: Advanced C# and .NET Framework

**31. What is `yield return` used for?**
`yield return` is used inside a method to create an **iterator**. It allows you to return an `IEnumerable<T>` or `IEnumerator<T>` without creating a collection in memory. The method's execution is paused and resumed at each iteration.

**32. How many generations does the Garbage Collector have?**
The .NET Garbage Collector (GC) has three generations:
*   **Generation 0**: Contains newly allocated, short-lived objects. This generation is collected most frequently.
*   **Generation 1**: Contains objects that survived a Gen 0 collection. It acts as a buffer between short-lived and long-lived objects.
*   **Generation 2**: Contains long-lived objects that survived a Gen 1 collection. This generation is collected least frequently.

**33. What is `Interlocked` class used for?**
The `System.Threading.Interlocked` class provides static methods for performing simple atomic operations on variables (e.g., `Increment`, `Decrement`, `Add`, `Exchange`, `CompareExchange`). These operations are thread-safe and cannot be interrupted mid-operation.

**34. What is the code generated by compiler for auto-properties?**
For an auto-implemented property like `public int MyProperty { get; set; }`, the compiler generates a hidden, private backing field and implements the `get` and `set` accessors to read from and write to that field.
```csharp
// What you write:
public int MyProperty { get; set; }

// What the compiler generates (conceptually):
private int _myPropertyBackingField;
public int get_MyProperty()
{
    return _myPropertyBackingField;
}
public void set_MyProperty(int value)
{
    _myPropertyBackingField = value;
}
```

**35. How is Polymorphism implemented in C#?**
Polymorphism ("many forms") is primarily implemented in C# through:
*   **Method Overriding (Runtime Polymorphism)**: A derived class provides a specific implementation for a method that is already defined in its base class using the `virtual` and `override` keywords.
*   **Method Overloading (Compile-time Polymorphism)**: A class has multiple methods with the same name but different signatures (parameters). The correct method to call is determined at compile time.

**36. How is Encapsulation implemented in C#?**
Encapsulation is the bundling of data (fields) and the methods that operate on that data into a single unit (a class), while hiding the internal state from the outside world. It is implemented using:
*   **Access Modifiers** (`private`, `protected`, etc.) to hide internal fields.
*   **Properties** (`get`, `set` accessors) to provide controlled, public access to the private fields, allowing for validation or logic to be executed when the data is accessed.

**37. What is the difference between `ref` and `out` parameters?**
Both `ref` and `out` pass arguments by reference, meaning the method can modify the original variable.
*   **`ref`**: The variable **must be initialized** before it is passed to the method. The method can read and modify its value.
*   **`out`**: The variable **does not need to be initialized** before being passed. The method **must assign a value** to the parameter before it returns. It cannot read the value before assigning it.

**38. How does the `using` statement work?**
The `using` statement provides a convenient syntax that ensures an object implementing `IDisposable` is correctly disposed of. The compiler translates a `using` block into a `try...finally` block, with `Dispose()` called in the `finally` block.
```csharp
// C# 8 and later can use a using declaration:
using var reader = new StreamReader("file.txt");
// ... code that uses reader ...
// reader.Dispose() is called automatically at the end of the scope
```

**39. What is a delegate and how is it used?**
A delegate is a type-safe function pointer. It's an object that holds a reference to a method (or multiple methods). It is used to:
*   Pass methods as arguments to other methods (callbacks).
*   Implement event handling (e.g., `EventHandler`).
*   Execute methods asynchronously.
*   Serve as the foundation for LINQ expressions and lambda functions.
```csharp
public delegate int MathOperation(int a, int b);

public int Add(int a, int b) => a + b;

// Create a delegate instance and use it
MathOperation op = Add;
int result = op(5, 3); // result is 8
```

**40. Explain method overloading and overriding**
*   **Overloading (Compile-time Polymorphism)**: Creating multiple methods in the same class with the same name but different signatures (number or type of parameters). The compiler decides which version to call.
*   **Overriding (Runtime Polymorphism)**: Providing a new implementation in a derived class for a `virtual` method defined in its base class. The method signature must be the same. The version that gets called is determined at runtime based on the actual type of the object.

**41. Difference between `IEnumerable` and `IQueryable`**
*   **`IEnumerable`**: Represents a sequence of objects that can be enumerated. When you use LINQ with `IEnumerable` (LINQ to Objects), the filtering and processing logic is executed in your application's memory.
*   **`IQueryable`**: Represents a query that can be executed against a specific data source (like a SQL database). It holds an **expression tree**, not the data itself. When you use LINQ with `IQueryable`, the query is translated to the target language (e.g., SQL) and executed on the server.

**42. What are expression trees in LINQ?**
An expression tree is a tree-like data structure that represents code as data. It is commonly used in `IQueryable` implementations to represent LINQ queries in a way that can be analyzed, modified, or translated to other query languages (like SQL). Expression trees allow queries to be executed on remote data sources.

---

### Part 4: Design Patterns in .NET

**43. What is the Singleton Pattern?**
The Singleton Pattern ensures that a class has only one instance and provides a global point of access to it. In modern C#, the simplest and most thread-safe way is using `Lazy<T>`:
```csharp
public sealed class Singleton
{
    private static readonly Lazy<Singleton> _instance = new Lazy<Singleton>(() => new Singleton());
    
    public static Singleton Instance => _instance.Value;
    
    private Singleton() { }
}
```

**44. Explain the Factory Pattern**
The Factory Pattern is a creational pattern that provides an interface for creating objects without specifying their exact classes. This decouples the client code from concrete implementations.
```csharp
public interface IShape { void Draw(); }
public class Circle : IShape { public void Draw() => Console.WriteLine("Drawing Circle"); }
public class Square : IShape { public void Draw() => Console.WriteLine("Drawing Square"); }

public class ShapeFactory
{
    public static IShape CreateShape(string type) => type switch
    {
        "circle" => new Circle(),
        "square" => new Square(),
        _ => throw new ArgumentException("Unknown shape")
    };
}
```

**45. What is the Observer Pattern?**
The Observer Pattern defines a one-to-many relationship where multiple objects (observers) subscribe to and are notified of changes in another object (subject). In .NET, this is implemented using **events and delegates**.
```csharp
public class Button
{
    public event EventHandler? Clicked;
    
    public void Click()
    {
        Clicked?.Invoke(this, EventArgs.Empty);
    }
}
```

**46. What is the Strategy Pattern?**
The Strategy Pattern defines a family of algorithms, encapsulates each one, and makes them interchangeable. This allows the algorithm to vary independently from clients that use it.
```csharp
public interface IPaymentStrategy { void Pay(decimal amount); }
public class CreditCardPayment : IPaymentStrategy { public void Pay(decimal amount) => Console.WriteLine($"Paid {amount} via credit card"); }
public class PayPalPayment : IPaymentStrategy { public void Pay(decimal amount) => Console.WriteLine($"Paid {amount} via PayPal"); }

public class ShoppingCart
{
    private IPaymentStrategy _paymentStrategy;
    
    public void SetPaymentStrategy(IPaymentStrategy strategy) => _paymentStrategy = strategy;
    public void Checkout(decimal amount) => _paymentStrategy.Pay(amount);
}
```

**47. Explain the Dependency Injection Pattern**
Dependency Injection (DI) is a design pattern that deals with how components get hold of their dependencies. The Dependency Injection Container (like built into .NET Core) automatically resolves and injects dependencies.
```csharp
public interface IEmailService { void SendEmail(string to, string message); }
public class EmailService : IEmailService { public void SendEmail(string to, string message) => Console.WriteLine($"Email sent to {to}"); }

public class UserService
{
    private readonly IEmailService _emailService;
    
    public UserService(IEmailService emailService) => _emailService = emailService;
    
    public void RegisterUser(string email) => _emailService.SendEmail(email, "Welcome!");
}

// In Startup.cs or Program.cs
services.AddScoped<IEmailService, EmailService>();
services.AddScoped<UserService>();
```

**48. What is the Decorator Pattern?**
The Decorator Pattern allows behavior to be added to objects dynamically. Instead of modifying the original class, you wrap it with a decorator that adds extra functionality.
```csharp
public interface IComponent { void Operation(); }
public class ConcreteComponent : IComponent { public void Operation() => Console.WriteLine("Base operation"); }

public abstract class Decorator : IComponent
{
    protected IComponent _component;
    public Decorator(IComponent component) => _component = component;
    public virtual void Operation() => _component.Operation();
}

public class ConcreteDecorator : Decorator
{
    public ConcreteDecorator(IComponent component) : base(component) { }
    
    public override void Operation()
    {
        base.Operation();
        Console.WriteLine("Additional operation");
    }
}
```

---

### Part 5: Performance Optimization and Memory Management

**49. What is object pooling and when should you use it?**
Object pooling is a technique where expensive-to-create objects are reused rather than created and destroyed repeatedly. It's useful for objects that are:
- Expensive to instantiate
- Created frequently in short bursts
- Have significant initialization overhead

```csharp
public class ObjectPool<T> where T : class, new()
{
    private readonly Stack<T> _objects = new();
    
    public T GetObject() => _objects.Count > 0 ? _objects.Pop() : new T();
    public void ReturnObject(T obj) => _objects.Push(obj);
}
```

**50. What are the performance implications of LINQ?**
While LINQ is convenient, it has performance considerations:
- **Deferred execution** means queries aren't executed until enumerated
- **Multiple enumerations** execute the query multiple times
- **LINQ to Objects** performs in-memory filtering (slower for large datasets than database filtering)
- **Allocations** for intermediate objects and closures can impact memory
- Use `ToList()` only when necessary; avoid multiple enumerations of the same query

**51. Explain the concept of GC pressure**
GC (Garbage Collector) pressure refers to the amount of work the garbage collector must do. High GC pressure results from:
- **Excessive allocations**: Creating too many objects, especially in hot paths
- **Large object allocations**: Objects >85KB go to the Large Object Heap (LOH)
- **Long-lived objects**: Objects that survive Gen 0 collections increase GC pauses

Reduce GC pressure by: reusing objects (pooling), avoiding unnecessary allocations, using `ArrayPool<T>` for temporary buffers.

**52. When should you use `struct` vs `class`?**
Use **`struct`** when:
- The data is small (typically <16 bytes)
- It represents a single value (like coordinates, color)
- You need value semantics and stack allocation
- It's immutable

Use **`class`** when:
- The object is large or frequently passed around
- You need inheritance
- You need reference semantics
- Identity matters (object references)

**53. What is the purpose of `stackalloc`?**
`stackalloc` allocates memory on the stack instead of the heap. This is faster (no GC needed) but limited by stack size. Use it for small, temporary buffers:
```csharp
Span<int> numbers = stackalloc int[10];
for (int i = 0; i < numbers.Length; i++)
    numbers[i] = i;
```

**54. Explain `Span<T>` and `Memory<T>`**
*   **`Span<T>`**: A stack-only type that represents a contiguous region of memory. It can point to arrays, strings, or stack memory. It's zero-copy and allocation-free.
*   **`Memory<T>`**: A heap-allocated wrapper around a region of memory. Unlike `Span<T>`, it can be stored in fields and passed asynchronously.

```csharp
var array = new int[] { 1, 2, 3, 4, 5 };
Span<int> span = array;
Memory<int> memory = array;
```

---

### Part 6: Entity Framework Core Advanced Topics

**55. What is the difference between `SaveChanges()` and `SaveChangesAsync()`?**
*   **`SaveChanges()`**: Synchronous method that blocks the calling thread until all changes are persisted to the database.
*   **`SaveChangesAsync()`**: Asynchronous method that doesn't block the thread. It returns a `Task` that completes when the changes are saved. This is preferred in async contexts and web applications for better resource utilization.

**56. Explain the different loading strategies in EF Core**
*   **Eager Loading**: Load related data immediately using `Include()`. Reduces the number of queries but may load unnecessary data.
    ```csharp
    var users = dbContext.Users.Include(u => u.Orders).ToList();
    ```
*   **Lazy Loading**: Related data is loaded automatically when accessed (requires `IAsyncQueryProvider`). Can cause N+1 query problems if not careful.
*   **Explicit Loading**: Manually load related data using `Load()` or `LoadAsync()`.
    ```csharp
    dbContext.Entry(user).Collection(u => u.Orders).Load();
    ```

**57. What is the N+1 query problem?**
The N+1 query problem occurs when you execute 1 query to fetch N records, then execute N additional queries to fetch related data for each record. This results in N+1 total queries, which is inefficient.

Solution: Use eager loading with `Include()` to fetch related data in a single query.

**58. What is the difference between `AsNoTracking()` and `AsTracking()`?**
*   **`AsNoTracking()`**: EF Core doesn't track changes to entities returned by the query. Useful for read-only scenarios. Faster and uses less memory because the change tracker is bypassed.
*   **`AsTracking()` (default)**: EF Core tracks changes, allowing you to modify entities and have those changes persisted via `SaveChanges()`.

```csharp
var users = dbContext.Users.AsNoTracking().ToList(); // For read-only
var users = dbContext.Users.AsTracking().ToList();    // For updates
```

**59. How do you handle concurrency in EF Core?**
EF Core provides two concurrency control mechanisms:
*   **Optimistic Concurrency**: Assumes conflicts are rare. Uses a `RowVersion` or `ConcurrencyToken` to detect changes made by other users.
    ```csharp
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [ConcurrencyCheck]
        public byte[] RowVersion { get; set; }
    }
    ```
*   **Pessimistic Concurrency**: Locks rows during updates. Prevents conflicts but can reduce concurrency (not directly supported by EF Core; use database locking).

**60. What is query splitting and how does it improve performance?**
Query splitting (introduced in EF Core 5.0) divides a single query with multiple `Include()` clauses into separate queries. This can improve performance when dealing with circular dependencies or collection navigation properties:
```csharp
dbContext.Users.Include(u => u.Orders).AsSplitQuery().ToList();
// Executes 2 queries: one for Users, one for Orders (separately)
```

---

### Part 7: Asynchronous Programming Deep Dive

**61. What is the difference between `Task` and `Task<T>`?**
*   **`Task`**: Represents an asynchronous operation that doesn't return a value. Use when you only care about completion.
*   **`Task<T>`**: Represents an asynchronous operation that returns a value of type `T`. Use when you need a result from the operation.

```csharp
async Task LogAsync() { /* no return value */ }
async Task<int> GetNumberAsync() { return 42; }
```

**62. Explain `async`/`await` vs `.ContinueWith()`**
*   **`async`/`await`**: Modern, cleaner syntax that reads like synchronous code. The compiler generates a state machine. Generally preferred.
*   **`.ContinueWith()`**: Older approach using continuation callbacks. More verbose and harder to read. Chains operations on tasks.

```csharp
// async/await
var result = await GetNumberAsync();

// ContinueWith
GetNumberAsync().ContinueWith(t => Console.WriteLine(t.Result));
```

**63. What is the purpose of `ConfigureAwait(false)`?**
`ConfigureAwait(false)` tells the Task to **not** capture the current synchronization context when awaiting. This is useful in library code to avoid unnecessary context switching, improving performance and avoiding potential deadlocks.

```csharp
public async Task<string> GetDataAsync()
{
    var response = await httpClient.GetStringAsync(url).ConfigureAwait(false);
    return response;
}
```

Use it in library code; generally not needed in UI or ASP.NET applications where the context matters.

**64. What is a `TaskScheduler` and how does it work?**
A `TaskScheduler` is responsible for scheduling `Task` instances for execution. The default `TaskScheduler` uses the ThreadPool. Custom schedulers can be created for specific scenarios (e.g., scheduling tasks on the UI thread):

```csharp
var uiScheduler = TaskScheduler.FromCurrentSynchronizationContext();
Task.Run(() => DoWork(), uiScheduler); // Runs on UI thread
```

**65. Explain the deadlock risk in `Task.Wait()` and `Task<T>.Result`**
Calling `Task.Wait()` or accessing `Task<T>.Result` synchronously blocks the calling thread. If the task tries to use the same `SynchronizationContext`, it will deadlock:

```csharp
// DEADLOCK RISK
public void BadMethod()
{
    var result = GetDataAsync().Result; // Blocks thread
}

// CORRECT
public async Task<string> GoodMethod()
{
    return await GetDataAsync(); // Async all the way
}
```

Always use `await` instead of blocking on tasks.

---

### Part 8: Common Pitfalls and Best Practices

**66. What is the "async void" anti-pattern?**
`async void` should only be used for event handlers. Using it elsewhere makes error handling and task completion tracking difficult:

```csharp
// BAD - Don't do this
async void ProcessDataAsync() { /* ... */ }

// GOOD
async Task ProcessDataAsync() { /* ... */ }

// OK - Event handler
private async void Button_Click(object sender, EventArgs e) { /* ... */ }
```

**67. Explain why you should avoid `new Thread()` and use `Task` instead**
`new Thread()` creates a real OS thread, which is expensive and resource-intensive. `Task` uses the ThreadPool, which is more efficient:
- ThreadPool reuses threads, reducing overhead
- Better scalability for thousands of concurrent operations
- Integrates with async/await
- Easier debugging and cancellation

```csharp
// OLD - Avoid
new Thread(() => DoWork()).Start();

// NEW - Prefer
Task.Run(() => DoWork());
```

**68. What is the issue with mutable default parameters?**
Mutable objects (lists, dictionaries) used as default parameters are created once and reused across all calls. Changes to one call's parameter affect all subsequent calls:

```csharp
// WRONG - Mutable list as default
public void AddItem(string item, List<string> items = null)
{
    items ??= new List<string>();
    items.Add(item);
}

// CORRECT
public void AddItem(string item, List<string>? items = null)
{
    items ??= new List<string>();
    items.Add(item);
}
```

**69. Explain why you shouldn't catch bare `Exception`**
Catching `Exception` catches all exceptions, including `OutOfMemoryException`, `StackOverflowException`, and `ThreadAbortException`, which should not be caught:

```csharp
// BAD
try { /* ... */ }
catch (Exception ex) { /* This hides critical errors */ }

// GOOD
try { /* ... */ }
catch (OperationCanceledException ex) { /* Handle specific exception */ }
catch (IOException ex) { /* Handle specific exception */ }
```

**70. What is the issue with forgetting to use `params` keyword?**
Without `params`, you force callers to create arrays manually, reducing usability:

```csharp
// BAD - Forces array creation
public void Log(string[] messages) { }
Log(new[] { "message1", "message2" });

// GOOD - Caller can pass arguments directly
public void Log(params string[] messages) { }
Log("message1", "message2");
```

**71. Explain the difference between `.Any()` and `.Count() > 0`**
Both check if a collection has elements, but differ in efficiency:
- **`.Any()`**: Stops after finding the first element. O(1) in most cases.
- **`.Count() > 0`**: Enumerates the entire collection. O(n).

Use `.Any()` for existence checks:
```csharp
if (items.Any()) { /* collection has items */ }      // Efficient
if (items.Count() > 0) { /* collection has items */ } // Less efficient
```

**72. What is the issue with using `default` for reference types?**
Using `default` returns `null` for reference types, which can cause `NullReferenceException` if not handled:

```csharp
// RISKY
public T GetDefault<T>() => default; // Returns null for classes

// SAFER
public T? GetDefault<T>() where T : class? => null;
```

---

### Quick Reference: C# Version Features

**C# 7.0 (2017)**
- Tuples: `(int x, int y) tuple = (1, 2);`
- Pattern Matching: `if (obj is int i) { }`
- Local functions

**C# 7.1 (2017)**
- Default expressions: `default`
- Inferred tuple names

**C# 8.0 (2019)**
- Nullable reference types
- Switch expressions
- Default interface members
- Records (preview)
- `using` declarations

**C# 9.0 (2020)**
- Records (official)
- Init-only properties: `public int Count { get; init; }`
- Top-level statements
- Pattern matching improvements

**C# 10.0 (2021)**
- Global usings
- File-scoped types: `file class MyClass`
- Record structs
- Lambda improvements

**C# 11.0 (2022)**
- Raw string literals: `"""multi-line string"""`
- UTF-8 string literals
- Generic attributes
- Required keyword: `required int Id;`

**C# 12.0 (2023)**
- Primary constructors
- Collection expressions: `int[] array = [1, 2, 3];`
- Inline arrays: `[System.Runtime.InteropServices.InlineArray(10)] public struct Buffer`
